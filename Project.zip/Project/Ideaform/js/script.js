$(document).ready(function() {

    $('form').submit(function(event) {

        var formData = {
            'email'              : $('#inputEmail').val(),
            'title'             : $('#ideaTitle').val(),
            'description'             : $('#ideaDescription').val(),
            'category'             : $('#ideaCategory').val(),
            'image'             : $('#ideaImage').val(),
            'privacy'             : $('input[name=ideaPrivacy]').val()

        };

        //Image Vaidation
        var allowedExtension = ['jpeg', 'jpg', 'gif', 'png'];
        var fileExtension = $('#ideaImage').val().split('.').pop().toLowerCase();
        var isValidFile = false;
        for(var index in allowedExtension) {
            if(fileExtension === allowedExtension[index]) {
                isValidFile = true; 
                break;
            }
        }
        if(!isValidFile) {
        alert('Allowed Extensions are : *.' + allowedExtension.join(', *.'));
        }
        else {
             //process the form and send data
        $.ajax({
            type        : 'POST', 
            url         : 'https://httpbin.org/post', 
            data        : formData, 
            dataType    : 'json', 
            encode      : true
        })
            .done(function(data) {

                //Hide form and display block
                $('.idea-form').hide();
                $('#main').html(JSON.stringify(data));

                console.log(data); 
            });
        }
        //Prevent Submit Deafault action
        event.preventDefault();
    });

});
