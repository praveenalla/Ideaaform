# Project Title

Ideaform

## Getting Started

Create Project Folder :Ideaform
Inside Ideaform folder create 3 more folders like css,fonts,js and one webpage file (index.html)
css folder place :bootstrap.min.css and styles.css files for webpage styling.
Fonts folder place : glyphicons-halflings-regular.eot,glyphicons-halflings-regular.svg,glyphicons-halflings-regular.ttf,glyphicons-halflings-regular.woff,glyphicons-halflings-regular.woff2 files.
js folder place: bootstrap.min.js,script.js files.

### Prerequisites

What things you need to install the software and how to install them

```
Markup language: HTML5 to create webpage (index.html)
FrontEnd FrameWork: Bootstrap
For Styling (CSS) :
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/styles.css" rel="stylesheet">
	
Javascript libraries:     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
```

### Steps to run code
```
Step1: click project->Ideaform->index.html
step 2: once you click index.html page you will get ideacapture form in browser window.
step 3: fill all the required fields  and click on Sigin on sucessfull submission
step 4: Browser hide Ideacaptureform and show you Returned json string in div with appropriate message.
```

### Form processing & Validations file
```
You can find Form processing logic and validation functions in Script.js file in JS folder..

```





